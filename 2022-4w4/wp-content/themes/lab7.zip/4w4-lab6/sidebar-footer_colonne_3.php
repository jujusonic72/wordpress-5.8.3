<div id="sidebar-footer-colonne-3" class="sidebar">
    <?php dynamic_sidebar('footer_colonne_3'); ?>
</div>