<div id="sidebar-entete-1" class="sidebar">
    <?php dynamic_sidebar('entete_1'); ?>
</div>