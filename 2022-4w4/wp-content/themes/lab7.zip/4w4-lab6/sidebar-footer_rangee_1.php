<div id="sidebar-footer-rangee-1" class="sidebar">
    <?php dynamic_sidebar('footer_rangee_1'); ?>
</div>