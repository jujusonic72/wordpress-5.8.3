<?php get_header(); ?>
<main class="site__main">
    <section class="erreur-404">
        <h1>:(</h1>
        <h2>Erreur 404</h2>
        <p>La page n'existe pas</p>
    </section>
</main>
<?php get_footer();  ?>