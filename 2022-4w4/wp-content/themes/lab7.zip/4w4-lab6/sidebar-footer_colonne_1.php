<div id="sidebar-footer-colonne-1" class="sidebar">
    <?php dynamic_sidebar('footer_colonne_1'); ?>
</div> 